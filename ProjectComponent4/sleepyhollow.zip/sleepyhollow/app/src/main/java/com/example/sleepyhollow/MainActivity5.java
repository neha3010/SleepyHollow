package com.example.sleepyhollow;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class MainActivity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main5);
        String ssn = getIntent().getStringExtra("ssn");
        Spinner spinner2=findViewById(R.id.spinner2);
        TextView textView12=findViewById(R.id.textView12);
        TableLayout table2=findViewById(R.id.table2);
        ArrayList<String> list=new ArrayList<>();
        RequestQueue queue= Volley.newRequestQueue(this);
        String awardUrl1 = "http://10.0.2.2:8080/sleepyhollow/AwardIds.jsp?ssn=" + ssn;
        StringRequest request51=new StringRequest(StringRequest.Method.GET, awardUrl1, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                String result=s.trim();
                String[] rows=result.split("#");
                for(int i=0;i<rows.length;i++){
                    String[] cols=rows[i].split(",");
                    list.add(cols[0]);
                }
                ArrayAdapter<String> adapter=new ArrayAdapter<>(MainActivity5.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,list);
                spinner2.setAdapter(adapter);
            }
        },null);
        queue.add(request51);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String Id=parent.getSelectedItem().toString();
                String url="http://10.0.2.2:8080/sleepyhollow/GrantedDetails.jsp?awardid="+Id+"&ssn="+ssn;
                StringRequest request52=new StringRequest(StringRequest.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        String result=s.trim();
                        String[] rows1=result.split("#");
                        table2.removeAllViews();
                        //String[] labels={"Prod Name  ","Price  ","Quantity  "};
                        textView12.setText("Award Date     Award Centre  ");

                        for(int i=0;i<rows1.length;i++){
                            String[] cols=rows1[i].split(",");
                            TableRow row = new TableRow(MainActivity5.this);
                            for(int k=0;k<cols.length;k++){
                                // Create a TextView for each column
                                TextView textView = new TextView(MainActivity5.this);
                                String text=cols[k]+"    ";
                                if(k==0){
                                    String[] date = cols[0].split(" ");
                                    text = date[0] + "    ";
                                }
                                textView.setText(text);
                                // Add the TextView to the row
                                row.addView(textView);
                            }
                            // Add the row to the tableLayout
                            table2.addView(row);
                        }
                    }
                },null);
                queue.add(request52);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}