package com.example.sleepyhollow;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main3);
        String ssn = getIntent().getStringExtra("ssn");
        TextView textView16 = findViewById(R.id.textView16);
        TableLayout table3 = findViewById(R.id.table3);
        RequestQueue queue = Volley.newRequestQueue(this);
        String transUrl = "http://10.0.2.2:8080/sleepyhollow/Transactions.jsp?ssn=" + ssn;
        StringRequest request31 = new StringRequest(Request.Method.GET, transUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                String result = s.trim();
                String[] rows2 = result.split("#");
                table3.removeAllViews();
                textView16.setText("Txn ID      date      amount  ");
                for (int i = 0; i < rows2.length; i++) {
                    String[] cols = rows2[i].split(",");
                    TableRow row = new TableRow(MainActivity3.this);

                    for (int k = 0; k < cols.length; k++) {
                        TextView textView = new TextView(MainActivity3.this);
                        textView.setText(cols[k] + "      ");
                        textView.setPadding(4, 4, 4, 4);  // Set padding for better readability
                        row.addView(textView);
                    }
                    table3.addView(row);
                }
            }
        }, null);
        queue.add(request31);


    }
}
