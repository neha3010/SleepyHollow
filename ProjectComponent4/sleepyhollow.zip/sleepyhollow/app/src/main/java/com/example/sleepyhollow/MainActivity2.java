package com.example.sleepyhollow;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity2 extends AppCompatActivity {

    private RequestQueue queue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        TextView textView4 = findViewById(R.id.textView4);
        String eid  = getIntent().getStringExtra("username");
        String ssn = getIntent().getStringExtra("ssn");

        textView4.setText(eid);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        Button button4 = findViewById(R.id.button4);
        Button button5 = findViewById(R.id.button5);
        Button button6 = findViewById(R.id.button6);

        ImageView imageView = findViewById(R.id.imageView);
        TextView textView17 = findViewById(R.id.textView17);

        queue = Volley.newRequestQueue(this);


        String imageUrl = "http://10.0.2.2:8080/sleepyhollow/images/" + ssn + ".jpeg";

        ImageRequest imageRequest = new ImageRequest(imageUrl, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap bitmap) {
                imageView.setImageBitmap(bitmap);
                button2.setEnabled(true);  // Enable the button once everything is loaded
            }
        }, 0, 0, null, null);

        queue.add(imageRequest);

        String infoUrl = "http://10.0.2.2:8080/sleepyhollow/info.jsp?ssn="+ssn;
        StringRequest request21 = new StringRequest(StringRequest.Method.GET, infoUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                String res = s.trim();
                String[] parts = res.split("#");

                String[] subParts = parts[0].split(",");
                textView17.setText("$" + subParts[1]);
            }
        }, null);

        queue.add(request21);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                        Intent intent2 = new Intent(MainActivity2.this, MainActivity3.class);
                        intent2.putExtra("ssn", ssn);
                        startActivity(intent2);

            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(MainActivity2.this, MainActivity4.class);
                intent3.putExtra("ssn", ssn);
                startActivity(intent3);


            }
        });
//
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent4 = new Intent(MainActivity2.this, MainActivity5.class);
                intent4.putExtra("ssn", ssn);
                startActivity(intent4);

            }
        });
//
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 Intent intent5 = new Intent(MainActivity2.this, MainActivity6.class);
                 intent5.putExtra("ssn", ssn);
                 startActivity(intent5);


            }
        });


        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(0);
            }
        });


    }
}