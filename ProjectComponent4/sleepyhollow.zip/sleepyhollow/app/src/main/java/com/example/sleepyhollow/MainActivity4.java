package com.example.sleepyhollow;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class MainActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main4);
        String ssn = getIntent().getStringExtra("ssn");
        Spinner spinner=findViewById(R.id.spinner);
        TextView textView13=findViewById(R.id.textView13);
        TextView textView14=findViewById(R.id.textView14);
        TextView textView15=findViewById(R.id.textView15);
        TableLayout table=findViewById(R.id.table);
        ArrayList<String> list=new ArrayList<>();
        RequestQueue queue= Volley.newRequestQueue(this);
        String transactionUrl1 = "http://10.0.2.2:8080/sleepyhollow/Transactions.jsp?ssn=" + ssn;
        StringRequest request41=new StringRequest(StringRequest.Method.GET, transactionUrl1, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                String result=s.trim();
                String[] rows=result.split("#");
                for(int i=0;i<rows.length;i++){
                    String[] cols=rows[i].split(",");
                    list.add(cols[0]);
                }
                ArrayAdapter<String> adapter=new ArrayAdapter<>(MainActivity4.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,list);
                spinner.setAdapter(adapter);
            }
        },null);
        queue.add(request41);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String Id=parent.getSelectedItem().toString();
                String url="http://10.0.2.2:8080/sleepyhollow/TransactionDetails.jsp?txnid="+Id;
                StringRequest request42=new StringRequest(StringRequest.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        String result=s.trim();
                        String[] rows1=result.split("#");
                        String date="";
                        int total_amount=0;
                        table.removeAllViews();
//                        String[] labels={"Prod Name  ","Price  ","Quantity  "};
                        textView13.setText("Prod Name   Price   Quantity  ");
                        for(int i=0;i<rows1.length;i++){
                            String[] cols=rows1[i].split(",");
                            if(i==0) {
                                String[] datetime = cols[0].split(" ");
                                date = datetime[0]+" ";
                            }
                            TableRow row = new TableRow(MainActivity4.this);
                            for(int k=2;k<cols.length;k++){
                                // Create a TextView for each column
                                TextView textView = new TextView(MainActivity4.this);
                                String text=cols[k]+"       ";
                                textView.setText(text);
                                // Add the TextView to the row
                                row.addView(textView);
                            }
                            // Add the row to the tableLayout
                            table.addView(row);
                            total_amount+=Integer.parseInt(cols[3])*Integer.parseInt(cols[4]);
                        }
                        textView14.setText(date);
                        textView15.setText("$"+String.valueOf(total_amount));

                    }
                },null);
                queue.add(request42);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
